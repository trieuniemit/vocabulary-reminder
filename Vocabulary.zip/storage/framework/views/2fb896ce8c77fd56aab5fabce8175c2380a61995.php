<?php $__env->startSection('content'); ?>
<div class="login_wrap p_120" style="padding-top: 40px;padding-bottom: 40px">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('user_profile')); ?>" class="login_form" method="post">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->has('errorlogin')): ?>
                        <div class="alert alert-danger" style="margin-top: 20px;">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo e($errors->first('errorlogin')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="username">Tên đăng nhập</label>
                        <?php if($errors->has('username')): ?>
							<p style="color:red"><?php echo e($errors->first('username')); ?></p>
						<?php endif; ?>
                        <input type="text" class="form-control" name="username" id="username" value="<?php echo e(old('username')); ?>" placeholder="Tên đăng nhập">
                      </div>
                      <div class="form-group">
                        <label for="fullname">Họ và tên</label>
                        <?php if($errors->has('fullname')): ?>
							<p style="color:red"><?php echo e($errors->first('fullname')); ?></p>
						<?php endif; ?>
                        <input type="text" class="form-control" name="fullname" id="fullname" value="<?php echo e(old('fullname')); ?>" placeholder="Nhập họ và tên">
                      </div>
                      <div class="form-group">
                        <label for="email">Địa chỉ email</label>
                        <?php if($errors->has('email')): ?>
							<p style="color:red"><?php echo e($errors->first('email')); ?></p>
						<?php endif; ?>
                        <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Nhập địa chỉ email">
                      </div>
                      <div class="form-group">
                        <label for="gender" class="control-label">Giới tính</label>
                        <select type="gender" name="gender" class="form-control wide" id="gender">
                            <option value="0">Nữ</option>
                            <option value="0">Nam</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="role" class="control-label">Quyền</label>
                        <select type="gender" name="gender" class="form-control wide" id="gender">
                            <option value="1">Administrator</option>
                            <option value="2">Vocabulary Manager</option>
                            <option value="3">User</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="birthday" class="control-label">Ngày sinh</label>
                        <?php if($errors->has('birthday')): ?>
							<p style="color:red"><?php echo e($errors->first('birthday')); ?></p>
						<?php endif; ?>
                        <input type="date" name="birthday" class="form-control wide" id="birthday" required>
                      </div>
                    <div class="row" style="padding-top: 30px">
                        <div class="col-sm-6">
                            <div class="login_btn">
                                <button type="button" onclick="window.history.back();" class="btn btn-info">< Quay lại</button>
     
                                <button type="submit" class="btn btn-success">Lưu lại</button>
                            </div>
                        </div>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Laravel\Vocabulary\resources\views/admin/users_manager_create.blade.php ENDPATH**/ ?>