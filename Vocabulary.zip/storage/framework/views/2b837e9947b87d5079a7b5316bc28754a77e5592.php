<?php $__env->startSection('content'); ?>
<div class="login_wrap p_120" style="padding-top: 80px">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Đăng nhập</h1>
            </div>
            <div class="col-md-12">
                <form action="<?php echo e(route('login_post')); ?>" class="login_form" method="post">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->has('errorlogin')): ?>
                        <div class="alert alert-danger" style="margin-top: 20px;">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo e($errors->first('errorlogin')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="email">Địa chỉ email</label>
                        <?php if($errors->has('email')): ?>
							<p style="color:red"><?php echo e($errors->first('email')); ?></p>
						<?php endif; ?>
                        <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Nhập địa chỉ email">
                      </div>
                      <div class="form-group">
                        <label for="password">Mật khẩu</label>
                        <?php if($errors->has('password')): ?>
							<p style="color:red"><?php echo e($errors->first('password')); ?></p>
						<?php endif; ?>
                        <input type="password" name="password" class="form-control" id="password" placeholder="Nhập mật khẩu">
                      </div>
                      <div class="checkbox">
                        <label>
                          <input type="checkbox" name="remember_me" checked> Ghi nhớ mật khẩu?
                        </label>
                      </div>
                    <div class="login_social">
                        <a href="#" class="btn-login-with facebook">
                            <i class="fa fa-facebook-official"></i>
                            Đăng nhập với Facebook
                        </a>
                        <a href="#" class="btn-login-with google">
                            <i class="fa fa-facebook-official"></i>
                            Đăng nhập với Google
                        </a>
                    </div>    
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="login_btn">
                                <button type="button" onclick="window.history.back();" class="btn btn-info">< Quay lại</button>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="login_btn">
                                <button type="submit" class="btn btn-success">Đăng nhập</button>
                            </div>
                        </div>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Laravel\Vocabulary\resources\views/login.blade.php ENDPATH**/ ?>