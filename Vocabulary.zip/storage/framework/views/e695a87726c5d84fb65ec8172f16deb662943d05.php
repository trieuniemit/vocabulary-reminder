<?php $__env->startSection('content'); ?>
<div class="login_wrap p_120" style="padding-top: 30px; padding-bottom: 70px">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('admin_setting')); ?>" class="login_form" method="post">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->has('errorlogin')): ?>
                        <div class="alert alert-danger" style="margin-top: 20px;">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo e($errors->first('errorlogin')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="facebook">Đường dẫn facebook</label>
                        <?php if($errors->has('facebook')): ?>
							<p style="color:red"><?php echo e($errors->first('facebook')); ?></p>
						<?php endif; ?>
                        <input type="text" class="form-control" name="facebook" id="facebook" value="" placeholder="https://facebook.com">
                      </div>
                      <div class="form-group">
                        <label for="youtube">Đường dẫn youtebe</label>
                        <?php if($errors->has('youtube')): ?>
							<p style="color:red"><?php echo e($errors->first('youtube')); ?></p>
						<?php endif; ?>
                        <input type="text" class="form-control" name="youtube" id="youtube" value="" placeholder="https://youtube.com">
                      </div>
                      <div class="form-group">
                        <label for="twitter">Đường dẫn twitter</label>
                        <?php if($errors->has('twitter')): ?>
							<p style="color:red"><?php echo e($errors->first('twitter')); ?></p>
						<?php endif; ?>
                        <input type="twitter" class="form-control" name="twitter" id="twitter" value="" placeholder="https://twitter.com">
                      </div>
                     
                      <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="can_register" class="control-label">Cho phép thành viên đăng ký mới?</label>
                                <select type="can_register" name="can_register" class="form-control wide" id="can_register">
                                    <option value="1">Có</option>
                                    <option value="0">Không</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label for="can_comment" class="control-label">Cho phép thành viên bình luận?</label>
                                <select type="can_comment" name="can_comment" class="form-control wide" id="can_comment">
                                    <option value="1">Có</option>
                                    <option value="0">Không</option>
                                </select>
                              </div>
                        </div>
                    </div>
                      
                    <div class="row" style="padding-top: 30px">
                        <div class="col-sm-6">
                            <div class="login_btn">
                                <button type="button" onclick="window.history.back();" class="btn btn-info">< Quay lại</button>
                                <button type="submit" class="btn btn-success">Lưu cài đặt</button>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Laravel\Vocabulary\resources\views/admin/system_settings.blade.php ENDPATH**/ ?>