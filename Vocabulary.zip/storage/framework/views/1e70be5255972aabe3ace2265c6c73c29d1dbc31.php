<?php $__env->startSection('content'); ?>
 <!-- DataTables Example -->
 <div class="card mb-3">
        <div class="card-header">
            <i class="fas fa-table"></i>
            Quản lý người dùng <a style="margin-left: 20px;" href="<?php echo e(route('users.create')); ?>"><i class="fas fa-plus"></i></a>
        </div>
        <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Tên người dùng</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Giới tính</th>
                    <th>Ngày sinh</th>
                    <th>Trạng thái</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Tên người dùng</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Giới tính</th>
                    <th>Ngày sinh</th>
                    <th>Trạng thái</th>
                    <th>Actions</th>
                </tr>
            </tfoot>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->fullname); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->gender==1?'Nữ': 'Nam'); ?></td>
                        <td><?php echo e($user->birthday); ?></td>
                        <td><?php echo $user->status==0?'<span style="color:green">Ngừng hoạt động</span>': '<span style="color:green">Hoạt động</span>'; ?></td>
                        <td style="text-align: center">
                            <a href="<?php echo e(route('users.index')); ?>/<?php echo e($user->id); ?>/edit" style="color:green"><i class="fas fa-edit" aria-hidden="true"></i></a> | 
                            <form style="display: inline" action="<?php echo e(route('users.index')); ?>/<?php echo e($user->id); ?>" method="post">
                                <button type="submit" style="color: red;padding: 0;border-width: 0px;background: none;"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo csrf_field(); ?>

                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\Laravel\Vocabulary\resources\views/admin/users_manager.blade.php ENDPATH**/ ?>