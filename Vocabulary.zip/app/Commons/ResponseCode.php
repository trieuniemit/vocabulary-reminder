<?php


namespace App\Commons;


class ResponseCode
{
    const success = 1;
    const fail = 2;
    const exception = 3;
}
